SET DATEFORMAT dmy
BULK INSERT a1704354.a1704354.[Entregan]
FROM 'e:\wwwroot\rcortese\entregan.csv'
WITH
(
    CODEPAGE = 'ACP',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)