
BULK INSERT a1704354.a1704354.[Materiales]
FROM 'e:\wwwroot\rcortese\materiales.csv'
WITH
(
    CODEPAGE = 'ACP',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)