BULK INSERT a1704354.a1704354.[Proyectos]
FROM 'e:\wwwroot\rcortese\proyectos.csv'
WITH
(
    CODEPAGE = 'ACP',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)