BULK INSERT a1704354.a1704354.[Proveedores]
FROM 'e:\wwwroot\rcortese\proveedores.csv'
WITH
(
    CODEPAGE = 'ACP',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)